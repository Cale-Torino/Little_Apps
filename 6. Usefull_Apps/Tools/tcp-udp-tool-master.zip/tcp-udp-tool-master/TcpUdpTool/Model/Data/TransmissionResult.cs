﻿using System.Net;

namespace TcpUdpTool.Model.Data
{
    public class TransmissionResult
    {
        public IPEndPoint From { get; set; }
        public IPEndPoint To { get; set; }

    }
}
