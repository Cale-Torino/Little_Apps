﻿using System;

namespace TcpUdpTool.ViewModel.Helper
{
    public interface IContentChangedHelper
    {

        event Action ContentChanged;

    }
}
