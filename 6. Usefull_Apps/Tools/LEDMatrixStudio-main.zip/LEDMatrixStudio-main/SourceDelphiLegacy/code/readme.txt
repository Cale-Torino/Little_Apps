LED Matrix Studio has been developed with Delphi Community Edition 10.3.
 The source code can be found at the link at the top of this document.

 If you wish to compile the product, or make your own changes, then download
 Delphi from here:
   
    https://www.embarcadero.com/products/delphi/starter