Version 0.20.22 is the first official stable releasee of the new C++ rewrite, and is available in the \portable folder. If you find a bug or any odd behaviour then please send me an email.

https://maximumoctopus.hashnode.dev/

\Portable\ contains the application in "portable" format

\Source\ contains the C++ rewrite (C++ Builder 11.3) and the current version being developed

\SourceDelphiLegacy\ contains the full Delphi 10.3 (Community Edition) source code
