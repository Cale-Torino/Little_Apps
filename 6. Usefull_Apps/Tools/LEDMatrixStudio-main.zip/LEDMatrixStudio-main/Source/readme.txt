C++ source code for the 2023/4 rewrite.

Written with C++ Builder 11.3 Community Edition

    https://www.embarcadero.com/products/cbuilder/starter

FOR THE FORSEEABLE FUTURE:

If it's in this folder then it compiles and will be mostly functional, but use at your own risk. It's not finished and there maybe bugs just waiting to be found.

For rewrite progress and other cool stuff (maybe even cat pictures), follow my new blog:

  https://maximumoctopus.hashnode.dev/

You will have to copy the LEDMatrixStudio folder structure (from the latest public beta build) to your build environment, otherwise some parts (like language selection) won't work or will cause errors. 

Paul, January 21st 2024
